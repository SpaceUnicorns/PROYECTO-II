#include "Animacion.h"



Animacion::Animacion()
{
}


Animacion::~Animacion()
{
}
