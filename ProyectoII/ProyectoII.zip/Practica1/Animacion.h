#pragma once
#include "Componente.h"
class Animacion :
	public Componente
{
public:
	Animacion();
	virtual ~Animacion();
};

